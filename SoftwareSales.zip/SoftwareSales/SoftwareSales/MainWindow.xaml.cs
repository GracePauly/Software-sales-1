﻿
using System.Windows;


namespace SoftwareSales
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private decimal quantity = 0;
        private decimal discount = 0;
        private decimal discountAmount = 0;
        private decimal totalAmountAfterDiscount=0;
        private decimal amountBeforeDiscount = 0;
        private decimal rate = 99;
        


        private const decimal TWENTY_PERCENT = (decimal)0.20;
        private const decimal THIRTY_PERCENT = (decimal)0.30;
        private const decimal FORTY_PERCENT = (decimal)0.40;
        private const decimal FIFTYY_PERCENT = (decimal)0.50;
        private const bool V = true;
       

        public MainWindow()
        {
            InitializeComponent();
            UserQuantity.Focus();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string userInput = UserQuantity.Text;
                quantity = decimal.Parse(userInput);
                if (quantity >= 100)
                {
                    DiscountFifty.IsChecked = true;
                    discount = FIFTYY_PERCENT;
                    MessageBox.Show("You have choosed quantity more than 100 so 50% discount is applied");
                }
                else if (quantity >= 50)
                {
                    DiscountForty.IsChecked = true;
                    discount = FORTY_PERCENT;
                    MessageBox.Show("You have choosed quantity more than 50  so 40% discount is applied");
                }
                else if (quantity >= 20)
                {
                    DiscountThirty.IsChecked = true;
                    discount = THIRTY_PERCENT;
                    MessageBox.Show("You have choosed quantity more than 20  so 30% discount is applied");
                }
                else if (quantity >= 10)
                {
                    DiscountTwenty.IsChecked = true;
                    discount = TWENTY_PERCENT;
                    MessageBox.Show("You have choosed quantity more than 10  so 20% discount is applied");
                }
                else
                {
                    DiscountZero.IsChecked = true;
                    discount = 0;
                    discountAmount = 0;
                    
                }

                discountAmount = rate *quantity * discount;
                TotalAmountCalculation();
                UpdateLabelContent();   
            }
            catch
            {
                _ = MessageBox.Show("Please Enter Number of Quantity");
               
                TotalAmountCalculation();
                UpdateLabelContent();
                UserQuantity.Focus();
            }
        }
       private void TotalAmountCalculation()
        {
            amountBeforeDiscount = rate * quantity;

            totalAmountAfterDiscount =  amountBeforeDiscount - discountAmount;
        }
        private void UpdateLabelContent()
        {
            DisplayDiscountAmount.Content = discountAmount.ToString("C");
            DisplayTotalAmount.Content = totalAmountAfterDiscount.ToString("C");
           
        }
    }
}
